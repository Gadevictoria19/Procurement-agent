\
import streamlit as st
import pandas as pd

from src.scoring import Constraints, DEFAULT_WEIGHTS
from src.agent import run_procurement_agent

st.set_page_config(page_title="ProcureX – Intel Procurement Agent", layout="wide")

st.title("ProcureX – Procurement Decision Agent")
st.caption("Compressed supplier intelligence + explainable optimization (Decision Trace + Counterfactuals).")

with st.sidebar:
    st.header("Inputs")
    suppliers_file = st.file_uploader("Upload suppliers.csv", type=["csv"])
    orders_file = st.file_uploader("Upload orders.csv", type=["csv"])

    st.header("Constraints (optional)")
    qty = st.number_input("Procurement quantity", min_value=0, value=5000, step=500)
    budget = st.number_input("Budget (total)", min_value=0.0, value=0.0, step=1000.0, help="Set 0 to ignore")
    deadline = st.number_input("Max lead time (days)", min_value=0, value=0, step=1, help="Set 0 to ignore")
    max_risk = st.number_input("Max risk score", min_value=0.0, max_value=1.0, value=0.0, step=0.05, help="Set 0 to ignore")
    min_on_time = st.number_input("Min on-time rate", min_value=0.0, max_value=1.0, value=0.0, step=0.05, help="Set 0 to ignore")
    max_defect = st.number_input("Max defect rate", min_value=0.0, max_value=1.0, value=0.0, step=0.01, help="Set 0 to ignore")

    st.header("Weights (unique + auditable)")
    w_cost = st.slider("Cost weight", 0.0, 1.0, float(DEFAULT_WEIGHTS["cost_per_unit"]), 0.05)
    w_on = st.slider("On-time weight", 0.0, 1.0, float(DEFAULT_WEIGHTS["on_time_rate"]), 0.05)
    w_def = st.slider("Quality (defect) weight", 0.0, 1.0, float(DEFAULT_WEIGHTS["defect_rate"]), 0.05)
    w_lead = st.slider("Lead time weight", 0.0, 1.0, float(DEFAULT_WEIGHTS["lead_time_days"]), 0.05)
    w_risk = st.slider("Risk weight", 0.0, 1.0, float(DEFAULT_WEIGHTS["risk_score"]), 0.05)

    if st.button("Load sample data"):
        suppliers_file = "data/suppliers.csv"
        orders_file = "data/orders.csv"

def read_csv(file):
    if isinstance(file, str):
        return pd.read_csv(file)
    return pd.read_csv(file)

if suppliers_file and orders_file:
    suppliers_df = read_csv(suppliers_file)
    orders_df = read_csv(orders_file)

    weights = {
        "cost_per_unit": w_cost,
        "on_time_rate": w_on,
        "defect_rate": w_def,
        "lead_time_days": w_lead,
        "risk_score": w_risk,
    }
    # normalize weights to sum to 1 (clean)
    s = sum(weights.values())
    if s > 0:
        weights = {k: v/s for k, v in weights.items()}

    constraints = Constraints(
        budget=budget if budget > 0 else None,
        deadline_days=int(deadline) if deadline > 0 else None,
        max_risk=max_risk if max_risk > 0 else None,
        min_on_time=min_on_time if min_on_time > 0 else None,
        max_defect=max_defect if max_defect > 0 else None,
        quantity=int(qty) if qty > 0 else None,
    )

    result = run_procurement_agent(suppliers_df, orders_df, weights=weights, constraints=constraints)

    st.subheader("1) Context Compression – Supplier Intelligence")
    st.dataframe(result["kpis"], use_container_width=True)

    st.subheader("2) Ranked Suppliers (Explainable Score)")
    st.dataframe(result["ranked_suppliers"], use_container_width=True)

    st.subheader("3) Decision Trace (Audit-Friendly)")
    trace = result["decision_trace"]
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**Reasons**")
        for r in trace.reasons:
            st.write("• " + r)
    with col2:
        st.markdown("**Counterfactuals**")
        if trace.counterfactuals:
            for c in trace.counterfactuals:
                st.write("• " + c)
        else:
            st.write("No runner-up available for counterfactual reasoning.")

    st.success(f"Recommended Supplier: {trace.recommended_supplier_id}")
else:
    st.info("Upload suppliers.csv and orders.csv, or click 'Load sample data' in the sidebar.")
