\
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import pandas as pd
import numpy as np

DEFAULT_WEIGHTS = {
    "cost_per_unit": 0.25,        # lower is better
    "on_time_rate": 0.30,         # higher is better
    "defect_rate": 0.25,          # lower is better
    "lead_time_days": 0.10,       # lower is better
    "risk_score": 0.10,           # lower is better
}

@dataclass
class Constraints:
    budget: Optional[float] = None
    deadline_days: Optional[int] = None
    max_risk: Optional[float] = None
    min_on_time: Optional[float] = None
    max_defect: Optional[float] = None
    quantity: Optional[int] = None

def _minmax(series: pd.Series, higher_is_better: bool) -> pd.Series:
    """Min-max normalize to [0,1]."""
    s = series.astype(float)
    lo, hi = float(s.min()), float(s.max())
    if hi - lo < 1e-12:
        norm = pd.Series(np.ones(len(s)), index=s.index, dtype=float)
    else:
        norm = (s - lo) / (hi - lo)
    return norm if higher_is_better else (1.0 - norm)

def compute_scores(
    suppliers_df: pd.DataFrame,
    weights: Dict[str, float] = DEFAULT_WEIGHTS,
    constraints: Optional[Constraints] = None,
) -> pd.DataFrame:
    """
    Compute a transparent, explainable supplier score using normalized features.
    Score is a weighted sum of normalized metrics (0..1). Higher is better.
    """
    df = suppliers_df.copy()

    # Apply hard constraints as filters (enterprise realistic)
    if constraints:
        if constraints.max_risk is not None:
            df = df[df["risk_score"] <= constraints.max_risk]
        if constraints.min_on_time is not None:
            df = df[df["on_time_rate"] >= constraints.min_on_time]
        if constraints.max_defect is not None:
            df = df[df["defect_rate"] <= constraints.max_defect]
        if constraints.deadline_days is not None:
            df = df[df["lead_time_days"] <= constraints.deadline_days]
        if constraints.quantity is not None:
            # capacity + MOQ constraints
            if "max_capacity" in df.columns:
                df = df[df["max_capacity"] >= constraints.quantity]
            if "min_order_qty" in df.columns:
                df = df[df["min_order_qty"] <= constraints.quantity]
        if constraints.budget is not None and constraints.quantity is not None:
            est_cost = df["cost_per_unit"] * float(constraints.quantity)
            df = df[est_cost <= constraints.budget]

    if df.empty:
        return df

    # Normalized columns for scoring
    norm = pd.DataFrame(index=df.index)
    norm["cost_per_unit_n"] = _minmax(df["cost_per_unit"], higher_is_better=False)
    norm["on_time_rate_n"] = _minmax(df["on_time_rate"], higher_is_better=True)
    norm["defect_rate_n"] = _minmax(df["defect_rate"], higher_is_better=False)
    norm["lead_time_days_n"] = _minmax(df["lead_time_days"], higher_is_better=False)
    norm["risk_score_n"] = _minmax(df["risk_score"], higher_is_better=False)

    # Weighted sum
    score = (
        weights["cost_per_unit"] * norm["cost_per_unit_n"] +
        weights["on_time_rate"] * norm["on_time_rate_n"] +
        weights["defect_rate"] * norm["defect_rate_n"] +
        weights["lead_time_days"] * norm["lead_time_days_n"] +
        weights["risk_score"] * norm["risk_score_n"]
    )

    out = df.reset_index(drop=True).copy()
    out["score"] = score.to_numpy()
    out = out.sort_values("score", ascending=False).reset_index(drop=True)

    # Attach normalized components for explainability
    for col in norm.columns:
        out[col] = norm.reset_index(drop=True)[col]

    return out
