\
from __future__ import annotations
from typing import Dict, Optional
import pandas as pd
from .analysis import compress_order_history
from .scoring import compute_scores, Constraints, DEFAULT_WEIGHTS
from .decision_trace import build_decision_trace, DecisionTrace

def run_procurement_agent(
    suppliers_df: pd.DataFrame,
    orders_df: pd.DataFrame,
    weights: Dict[str, float] = DEFAULT_WEIGHTS,
    constraints: Optional[Constraints] = None,
) -> dict:
    """
    End-to-end run:
    1) compress order history into supplier intelligence
    2) merge intelligence into supplier master
    3) rank suppliers with explainable scoring + constraints
    4) produce decision trace + counterfactual reasoning
    """
    kpis = compress_order_history(orders_df)

    # Merge KPIs (fill missing with neutral defaults)
    merged = suppliers_df.merge(kpis, on="supplier_id", how="left")
    merged["avg_delay_days"] = merged["avg_delay_days"].fillna(0.0)
    merged["avg_observed_defect"] = merged["avg_observed_defect"].fillna(merged["defect_rate"])

    ranked = compute_scores(merged, weights=weights, constraints=constraints)
    trace: DecisionTrace = build_decision_trace(ranked, weights=weights, quantity=getattr(constraints, "quantity", None) if constraints else None)

    return {
        "kpis": kpis,
        "ranked_suppliers": ranked,
        "decision_trace": trace,
    }
