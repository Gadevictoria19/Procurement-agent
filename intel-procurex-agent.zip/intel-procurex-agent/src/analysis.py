\
from __future__ import annotations
import pandas as pd

def compress_order_history(orders_df: pd.DataFrame) -> pd.DataFrame:
    """
    Compress raw order history into supplier-level intelligence (KPIs).
    This is the "context compression" layer.
    """
    df = orders_df.copy()
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")

    grp = df.groupby("supplier_id", dropna=False)
    summary = grp.agg(
        orders=("order_id", "count"),
        avg_qty=("quantity", "mean"),
        avg_delay_days=("delivery_delay_days", "mean"),
        p95_delay_days=("delivery_delay_days", lambda s: s.quantile(0.95)),
        avg_observed_defect=("defect_rate_observed", "mean"),
        total_spend=("total_cost", "sum"),
        last_order=("order_date", "max"),
    ).reset_index()

    # Simple derived signals
    summary["delay_risk_flag"] = (summary["p95_delay_days"] >= 7).astype(int)
    summary["quality_risk_flag"] = (summary["avg_observed_defect"] >= 0.03).astype(int)

    return summary.sort_values("total_spend", ascending=False).reset_index(drop=True)
