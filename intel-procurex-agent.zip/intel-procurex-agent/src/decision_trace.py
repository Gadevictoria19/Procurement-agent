\
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import pandas as pd

@dataclass
class DecisionTrace:
    recommended_supplier_id: str
    top_factors: List[Tuple[str, float]]
    reasons: List[str]
    counterfactuals: List[str]

def build_decision_trace(ranked_df: pd.DataFrame, weights: Dict[str, float], quantity: int | None = None) -> DecisionTrace:
    """
    Creates an audit-friendly trace:
    - Top contributing factors for winner vs runner-up
    - Human-readable reasons
    - Counterfactual reasoning: what would need to change for runner-up to win
    """
    if ranked_df.empty:
        raise ValueError("No suppliers available after constraints.")

    winner = ranked_df.iloc[0]
    runner = ranked_df.iloc[1] if len(ranked_df) > 1 else None

    # Contributions based on normalized components * weights
    contrib_cols = [
        ("cost_per_unit", "cost_per_unit_n"),
        ("on_time_rate", "on_time_rate_n"),
        ("defect_rate", "defect_rate_n"),
        ("lead_time_days", "lead_time_days_n"),
        ("risk_score", "risk_score_n"),
    ]
    contrib = []
    for raw, ncol in contrib_cols:
        contrib.append((raw, float(weights.get(raw, 0.0) * winner[ncol])))

    top_factors = sorted(contrib, key=lambda x: x[1], reverse=True)[:3]

    reasons = []
    reasons.append(f"Selected {winner['name']} ({winner['supplier_id']}) with top overall score {winner['score']:.3f}.")
    reasons.append("Top drivers: " + ", ".join([f"{k} ({v:.3f})" for k, v in top_factors]) + ".")
    if quantity is not None and "cost_per_unit" in winner:
        reasons.append(f"Estimated spend for quantity {quantity:,}: {winner['cost_per_unit']*quantity:,.2f}.")

    counterfactuals = []
    if runner is not None:
        # Simple counterfactual: how much runner needs to increase its score to surpass winner
        gap = float(winner["score"] - runner["score"])
        counterfactuals.append(
            f"Runner-up {runner['name']} ({runner['supplier_id']}) is behind by score gap {gap:.3f}."
        )
        # Suggest improvements on the biggest weaknesses (where runner has lower normalized values than winner)
        weaknesses = []
        for raw, ncol in contrib_cols:
            delta = float(winner[ncol] - runner[ncol])  # positive means runner worse
            weaknesses.append((raw, delta))
        weaknesses = sorted(weaknesses, key=lambda x: x[1], reverse=True)

        # Provide up to 2 counterfactuals
        for raw, delta in weaknesses[:2]:
            w = float(weights.get(raw, 0.0))
            if w <= 0 or delta <= 0:
                continue
            # how much normalized improvement needed if only this metric changes
            needed_norm = min(1.0, float(delta))  # upper bound
            approx_gain = w * needed_norm
            counterfactuals.append(
                f"If {runner['supplier_id']} improved {raw} enough to gain ~{approx_gain:.3f} score (holding others constant), it could challenge the top recommendation."
            )

    return DecisionTrace(
        recommended_supplier_id=str(winner["supplier_id"]),
        top_factors=top_factors,
        reasons=reasons,
        counterfactuals=counterfactuals,
    )
