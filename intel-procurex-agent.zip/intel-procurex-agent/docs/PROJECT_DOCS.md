# Project Documentation (ProcureX)

This folder contains additional documentation for the Intel AI Agents Challenge submission.

## Design choices
- Decisions are made via a transparent scoring model (auditable).
- LLMs are optional and used ONLY for explanation; decisions are deterministic.
- Includes Decision Trace & Counterfactual Reasoning for uniqueness and trust.

## How to extend
- Add ERP/SQL connectors
- Add real-time risk feeds (news, delays, region risk)
- Add multi-period / multi-supplier allocation optimization (LP)
