\
import pandas as pd
from src.scoring import compute_scores, Constraints

def test_scoring_runs():
    suppliers = pd.read_csv("data/suppliers.csv")
    ranked = compute_scores(suppliers, constraints=Constraints(quantity=5000))
    assert len(ranked) > 0
    assert "score" in ranked.columns
